$(document).ready(function () {
	$("input.web3000-search__input").on("click", function () {
		$(this).addClass("is-focused");
	});
});
